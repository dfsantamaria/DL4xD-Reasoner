#pragma once

#include <fstream>;

//#define test
#pragma once
int counterTest = 0;
int counterFormula = 0;
int counterFormulaIn = 0;
extern std::fstream testFile;