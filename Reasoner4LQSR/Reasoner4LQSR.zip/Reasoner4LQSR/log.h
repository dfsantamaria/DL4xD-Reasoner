#pragma once

#include <fstream>;

//#define debug                   //debug istructions
//#define debugclash              //debug istructions for clash checking
//#define debugexpand             //debug istructions for expansion rule
//#define debuginsertf            //debug istructions for internal formula translation
//#define eqsetdebug                 //debug istructions for computing EqSet
//#define debugquery               //debug istructions for query
//#define debugcnf                    //debug for CNF converter
//#define debugmvq                    //debug for moving quantifiers 
//#define debugparseXML               //debug xml parser
//#define debugnorm                   //debug normalization

extern std::fstream logFile;



