// stdafx.cpp : file di origine che include solo le inclusioni standard
// Reasoner4LQSR.pch sar� l'intestazione precompilata
// stdafx.obj conterr� le informazioni sui tipi precompilati

#include "stdafx.h"

// TODO: fare riferimento alle intestazioni aggiuntive necessarie in STDAFX.H
// e non in questo file
